# Astral Client — Fase 1 (base de desenvolvimento)

**Alvo:** Minecraft Java 1.8.9 + Forge 11.15.1.2318  
**Criador:** LazaroBW  
**Identidade:** verde, preto e laranja  
**Política do projeto:** sem hacks, cheats ou vantagens injustas.

## O que esta fase contém
- Projeto-fonte Forge 1.8.9.
- Registro do mod `astral`.
- Substituição da tela inicial vanilla por uma tela inicial Astral básica.
- Botões funcionais para Singleplayer, Multiplayer, Options e Sair.
- Crédito do criador somente no menu principal.

## O que ainda NÃO está nesta fase
- Não é um `.jar` compilado.
- Não é um pacote `.minecraft` pronto para importar.
- Logo oficial em imagem, fundo animado e animações refinadas ainda não foram integrados.
- Não foi testado no Zalith, Pojav ou MJ Launcher.

## Como compilar (computador)
1. Instale JDK 8.
2. Instale Gradle compatível com ForgeGradle 2.1 (ou use um wrapper Gradle 2.7 configurado).
3. Abra esta pasta no terminal.
4. Execute `gradle setupDecompWorkspace`.
5. Execute `gradle build`.
6. O JAR gerado ficará em `build/libs/`.

O ForgeGradle antigo depende dos repositórios Maven e pode exigir ajustes no ambiente atual. O arquivo compilado só deve ser considerado pronto depois de iniciar o Minecraft 1.8.9 Forge e abrir o menu sem crash.

## Próxima validação
Antes da Fase 2, validar:
- Minecraft 1.8.9 Forge inicia.
- Menu Astral aparece.
- Singleplayer, Multiplayer e Options abrem.
- Sair fecha o jogo.
- Nenhum crash ao retornar ao menu.
