package com.astral.client;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.EnumChatFormatting;

public class GuiAstralMainMenu extends GuiScreen {
    private static final int GREEN = 0xFF65D66E;
    private static final int PANEL = 0x990A0D0B;

    @Override
    public void initGui() {
        this.buttonList.clear();
        int w = 190;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 12;
        this.buttonList.add(new GuiButton(0, x, y, w, 20, I18n.format("menu.singleplayer")));
        this.buttonList.add(new GuiButton(1, x, y + 25, w, 20, I18n.format("menu.multiplayer")));
        this.buttonList.add(new GuiButton(2, x, y + 55, w, 20, I18n.format("menu.options")));
        this.buttonList.add(new GuiButton(3, x, y + 80, w, 20, "Sair"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();

        // Painel escuro translúcido e identidade visual verde/preto.
        drawRect(this.width / 2 - 145, this.height / 2 - 105,
                 this.width / 2 + 145, this.height / 2 + 125, PANEL);
        drawCenteredString(this.fontRendererObj,
                EnumChatFormatting.GOLD + "▲" + EnumChatFormatting.RESET,
                this.width / 2, this.height / 2 - 88, 0xFFFFA33A);
        drawCenteredString(this.fontRendererObj,
                EnumChatFormatting.GREEN + "ASTRAL CLIENT",
                this.width / 2, this.height / 2 - 69, GREEN);
        drawCenteredString(this.fontRendererObj,
                EnumChatFormatting.GRAY + "Minecraft 1.8.9",
                this.width / 2, this.height / 2 - 54, 0xFFB8B8B8);

        super.drawScreen(mouseX, mouseY, partialTicks);
        drawString(this.fontRendererObj, "Criador do Client: LazaroBW",
                6, this.height - 14, 0xFFB8B8B8);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0:
                this.mc.displayGuiScreen(new GuiSelectWorld(this));
                break;
            case 1:
                this.mc.displayGuiScreen(new GuiMultiplayer(this));
                break;
            case 2:
                this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
                break;
            case 3:
                this.mc.shutdown();
                break;
            default:
                break;
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
    }
}
