# Astral Client 0.3.0 — fase de teste

Projeto Forge para Minecraft Java 1.8.9. Esta fase substitui o menu principal por uma tela Astral própria, com botões Singleplayer, Multiplayer, Mods, Cosmetics, Options e Exit.

- Não inclui cheats, hacks ou módulos de vantagem injusta.
- OptiFine não é distribuído junto. Use uma instalação legítima e compatível de OptiFine 1.8.9.
- O inventário vanilla permanece sem alterações.
- Esta é uma build de teste; compile pelo workflow do GitHub Actions antes de instalar.
