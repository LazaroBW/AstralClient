package com.astral.client;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.EnumChatFormatting;

public class GuiAstralInfo extends GuiScreen {
    private final GuiScreen parent;
    private final String section;

    public GuiAstralInfo(GuiScreen parent, String section) {
        this.parent = parent;
        this.section = section;
    }

    @Override
    public void initGui() {
        buttonList.clear();
        buttonList.add(new GuiButton(0, width / 2 - 90, height - 42, 180, 24, "Voltar"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawGradientRect(0, 0, width, height, 0xE0101518, 0xF0000000);
        drawCenteredString(fontRendererObj, EnumChatFormatting.GREEN + "ASTRAL CLIENT",
            width / 2, 35, 0xFFFFFFFF);
        drawCenteredString(fontRendererObj, section, width / 2, 75, 0xFFFFFFFF);
        drawCenteredString(fontRendererObj, "Esta seção será expandida nas próximas fases.",
            width / 2, 105, 0xFFBFC6C8);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 0) mc.displayGuiScreen(parent);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
