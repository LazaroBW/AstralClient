package com.astral.client;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Mouse;

public class GuiAstralMainMenu extends GuiScreen {
    private static final ResourceLocation LOGO =
        new ResourceLocation("astral", "textures/gui/astral_logo.png");
    private int hovered = -1;

    @Override
    public void initGui() {
        buttonList.clear();
        int w = 190, h = 24, x = width / 2 - 95;
        int y = height / 2 - 20;
        buttonList.add(new GuiButton(0, x, y, w, h, "Singleplayer"));
        buttonList.add(new GuiButton(1, x, y + 30, w, h, "Multiplayer"));
        buttonList.add(new GuiButton(2, x, y + 60, 92, h, "Mods"));
        buttonList.add(new GuiButton(3, x + 98, y + 60, 92, h, "Cosmetics"));
        buttonList.add(new GuiButton(4, x, y + 90, w, h, "Options"));
        buttonList.add(new GuiButton(5, x, height - 38, 90, 20, "Sair"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawGradientRect(0, 0, width, height, 0xD8101518, 0xE9000000);
        // Subtle green ambient accents
        drawRect(0, height - 3, width, height, 0xFF63D471);
        drawRect(0, 0, width, 2, 0xAA63D471);

        GlStateManager.enableBlend();
        mc.getTextureManager().bindTexture(LOGO);
        int logoW = 92, logoH = 92;
        drawModalRectWithCustomSizedTexture(width / 2 - logoW / 2, 24, 0, 0, logoW, logoH, logoW, logoH);
        GlStateManager.disableBlend();

        drawCenteredString(fontRendererObj, EnumChatFormatting.WHITE + "ASTRAL CLIENT",
            width / 2, 124, 0xFFFFFFFF);
        drawCenteredString(fontRendererObj, EnumChatFormatting.GRAY + "Minecraft 1.8.9",
            width / 2, 139, 0xFFB7C0C4);

        for (int i = 0; i < buttonList.size(); i++) {
            GuiButton b = (GuiButton) buttonList.get(i);
            boolean over = mouseX >= b.xPosition && mouseY >= b.yPosition &&
                mouseX < b.xPosition + b.width && mouseY < b.yPosition + b.height;
            int fill = over ? 0xCC244C32 : 0x99303030;
            int border = over ? 0xFF72E18A : 0xFF60686B;
            drawRect(b.xPosition, b.yPosition, b.xPosition + b.width, b.yPosition + b.height, fill);
            drawRect(b.xPosition, b.yPosition, b.xPosition + b.width, b.yPosition + 1, border);
            drawRect(b.xPosition, b.yPosition + b.height - 1, b.xPosition + b.width, b.yPosition + b.height, border);
            drawCenteredString(fontRendererObj, b.displayString,
                b.xPosition + b.width / 2, b.yPosition + 7, over ? 0xFFFFFFFF : 0xFFE1E5E6);
        }
        drawString(fontRendererObj, "Criador do Client: LazaroBW", 8, height - 18, 0xFFBFC6C8);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0: mc.displayGuiScreen(new GuiSelectWorld(this)); break;
            case 1: mc.displayGuiScreen(new GuiMultiplayer(this)); break;
            case 2: mc.displayGuiScreen(new GuiAstralInfo(this, "Mods")); break;
            case 3: mc.displayGuiScreen(new GuiAstralInfo(this, "Cosmetics")); break;
            case 4: mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings)); break;
            case 5: mc.shutdown(); break;
        }
    }

    @Override
    public void updateScreen() { super.updateScreen(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
