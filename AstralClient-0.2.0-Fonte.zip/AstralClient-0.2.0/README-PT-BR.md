# Astral Client 0.2.0 — Fase visual

Projeto para Minecraft Java 1.8.9 + Forge 11.15.1.2318.

- Menu principal Astral redesenhado, visual escuro e clean.
- Logo em círculo branco com emblema preto/laranja.
- Botões Singleplayer, Multiplayer, Mods, Cosmetics, Options e Sair.
- Tela Mods inicial com opções visuais demonstrativas.
- Sem cheats, hacks ou vantagens injustas.

## Compilação
Use Java 8 e ForgeGradle 2.1 em ambiente compatível:
`gradle setupDecompWorkspace`
`gradle build`

O JAR fica em `build/libs/`. O código-fonte não é um JAR compilado. Teste no Minecraft 1.8.9 Forge antes de considerar a versão validada. Não foi testado em Pojav, Zalith ou MJ Launcher.
