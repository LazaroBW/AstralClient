package com.astral.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiButton;

public class GuiAstralMods extends GuiScreen {
    private final GuiScreen parent;
    public GuiAstralMods(GuiScreen parent) { this.parent = parent; }

    @Override
    public void initGui() {
        buttonList.clear();
        int x = width / 2 - 115;
        int y = height / 2 - 45;
        buttonList.add(new AstralButton(0, x, y, 230, 26, "HUD Editor  •  Em breve", false));
        buttonList.add(new AstralButton(1, x, y + 34, 230, 26, "Keystrokes  •  Em breve", false));
        buttonList.add(new AstralButton(2, x, y + 68, 230, 26, "CPS Counter  •  Em breve", false));
        buttonList.add(new AstralButton(3, x, y + 102, 230, 26, "Voltar", true));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawGradientRect(0, 0, width, height, 0xFF202630, 0xFF090B10);
        drawCenteredString(fontRendererObj, "ASTRAL  /  MODS", width / 2, 28, 0xFFF4F5F7);
        drawCenteredString(fontRendererObj, "Personalize sua interface", width / 2, 43, 0xFFADB5C0);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 3) mc.displayGuiScreen(parent);
    }
}
