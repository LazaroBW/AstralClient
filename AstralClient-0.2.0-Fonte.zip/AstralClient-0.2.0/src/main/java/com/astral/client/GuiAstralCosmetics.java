package com.astral.client;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiButton;

public class GuiAstralCosmetics extends GuiScreen {
    private final GuiScreen parent;
    public GuiAstralCosmetics(GuiScreen parent) { this.parent = parent; }

    @Override
    public void initGui() {
        buttonList.clear();
        buttonList.add(new AstralButton(0, width / 2 - 110, height / 2 + 25,
                220, 28, "Voltar", true));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawGradientRect(0, 0, width, height, 0xFF202630, 0xFF090B10);
        drawCenteredString(fontRendererObj, "ASTRAL  /  COSMETICS", width / 2, height / 2 - 30, 0xFFF4F5F7);
        drawCenteredString(fontRendererObj, "Cosméticos personalizados — próxima fase",
                width / 2, height / 2 - 12, 0xFFADB5C0);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 0) mc.displayGuiScreen(parent);
    }
}
