package com.astral.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.FontRenderer;

public class AstralButton extends GuiButton {
    private final boolean accent;

    public AstralButton(int id, int x, int y, int width, int height, String text, boolean accent) {
        super(id, x, y, width, height, text);
        this.accent = accent;
    }

    @Override
    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        if (!this.visible) return;
        this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition
                && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
        int fill = this.hovered ? 0xCC252A32 : 0x9920242B;
        int edge = this.hovered ? 0xFFFF9A24 : 0x887D8794;
        if (accent) {
            fill = this.hovered ? 0xDD382516 : 0xAA211A18;
            edge = this.hovered ? 0xFFFFA12B : 0xAAE58A2B;
        }
        drawRect(xPosition, yPosition, xPosition + width, yPosition + height, fill);
        drawRect(xPosition, yPosition, xPosition + width, yPosition + 1, edge);
        drawRect(xPosition, yPosition + height - 1, xPosition + width, yPosition + height, edge);
        drawRect(xPosition, yPosition, xPosition + 1, yPosition + height, edge);
        drawRect(xPosition + width - 1, yPosition, xPosition + width, yPosition + height, edge);
        int color = this.enabled ? (this.hovered ? 0xFFFFB45C : 0xFFF0F1F3) : 0xFF777777;
        FontRenderer fr = mc.fontRendererObj;
        drawCenteredString(fr, this.displayString, xPosition + width / 2,
                yPosition + (height - 8) / 2, color);
    }
}
