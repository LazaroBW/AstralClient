package com.astral.client;

import java.io.IOException;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.renderer.GlStateManager;

public class GuiAstralMainMenu extends GuiScreen {
    private static final ResourceLocation LOGO =
            new ResourceLocation("astral", "textures/gui/astral_logo.png");
    private long openedAt;

    @Override
    public void initGui() {
        openedAt = System.currentTimeMillis();
        buttonList.clear();
        int center = width / 2;
        int bw = Math.min(300, width - 36);
        int x = center - bw / 2;
        int h = 28;
        int y = Math.max(135, height / 2 - 28);
        buttonList.add(new AstralButton(0, x, y, bw, h, "Singleplayer", true));
        buttonList.add(new AstralButton(1, x, y + 35, bw, h, "Multiplayer", false));
        int half = (bw - 8) / 2;
        buttonList.add(new AstralButton(2, x, y + 70, half, h, "Mods", false));
        buttonList.add(new AstralButton(3, x + half + 8, y + 70, half, h, "Cosmetics", false));
        buttonList.add(new AstralButton(4, x, y + 105, bw, h, "Options", false));
        buttonList.add(new AstralButton(5, x, y + 140, bw, h, "Sair", false));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawGradientRect(0, 0, width, height, 0xFF202630, 0xFF090B10);
        // subtle decorative bands
        drawRect(0, 0, width, 3, 0xFFFF9826);
        drawRect(0, height - 3, width, height, 0xFF11151C);

        int cx = width / 2;
        int logoSize = Math.min(88, Math.max(60, height / 6));
        mc.getTextureManager().bindTexture(LOGO);
        GlStateManager.color(1F, 1F, 1F, 1F);
        drawModalRectWithCustomSizedTexture(cx - logoSize / 2, 16, 0, 0,
                logoSize, logoSize, logoSize, logoSize);

        drawCenteredString(fontRendererObj, "ASTRAL", cx, 16 + logoSize + 4, 0xFFF4F5F7);
        drawCenteredString(fontRendererObj, "C L I E N T", cx, 16 + logoSize + 17, 0xFFFF9B2F);

        // Account card, intentionally generic until account skin integration.
        drawRect(12, 12, 142, 43, 0x88343B46);
        drawRect(12, 12, 14, 43, 0xFFFF9826);
        drawString(fontRendererObj, mc.getSession().getUsername(), 22, 18, 0xFFF4F5F7);
        drawString(fontRendererObj, "Minecraft 1.8.9", 22, 30, 0xFFB4BBC5);

        super.drawScreen(mouseX, mouseY, partialTicks);
        drawString(fontRendererObj, "Criador do Client: LazaroBW", 12, height - 16, 0xFFD8DCE2);
        String version = "ASTRAL 0.2.0";
        drawString(fontRendererObj, version, width - fontRendererObj.getStringWidth(version) - 12,
                height - 16, 0xFF9DA5B0);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0: mc.displayGuiScreen(new GuiSelectWorld(this)); break;
            case 1: mc.displayGuiScreen(new GuiMultiplayer(this)); break;
            case 2: mc.displayGuiScreen(new GuiAstralMods(this)); break;
            case 3: mc.displayGuiScreen(new GuiAstralCosmetics(this)); break;
            case 4: mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings)); break;
            case 5: mc.shutdown(); break;
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
    }
}
